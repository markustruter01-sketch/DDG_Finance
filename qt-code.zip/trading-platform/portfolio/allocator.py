"""
Portfolio Allocator — Regime-Switching Architecture
-----------------------------------------------------
v5.0 — Institutional Refactor: Fixed Fractional + Quarter-Kelly + 10% Position Cap

Post-processes the raw LLM JSON output:

  Full Market (Regime) mode:
    1. Parse & validate with Pydantic.
    2. SPY EMA Anchor — override Bull → Sideways if SPY < EMA-20;
       replace all leveraged_risk slots with SGOV.
    3. Conviction threshold — low-conviction slots → SGOV.
    4. ── VOLATILITY-ADJUSTED SIZING (v4.4) ──────────────────────────────
       Replace even-weight with inverse-volatility sizing:
         weight_i ∝ 1 / annualised_volatility_i
       Target total deployment: 82 % of equity (TARGET_UTILIZATION).
       Per-asset cap: 10 % (MAX_POSITION_KELLY).
       Falls back to even-weight if volatility data unavailable.
       ──────────────────────────────────────────────────────────────────
    5. ── ASSET CLASS CONCENTRATION CAP (v4.4) ───────────────────────────
       Cap any single asset class to MAX_ASSET_CLASS_KELLY (35 %).
       Excess is swept into a SGOV slot so capital is explicitly bought.
       ──────────────────────────────────────────────────────────────────
    6. ── LEVERAGED FENCE (v4.3) ──────────────────────────────────────────
       Cap leveraged_risk group to MAX_LEVERAGED_KELLY (20 %).
       Excess swept to SGOV.
       ──────────────────────────────────────────────────────────────────
    7. Normalise Kelly fractions so total ≤ 1.0.
    8. Return validated RegimeAnalysisOutput.

  Crypto-Only mode (off-hours):
    Same pipeline for CryptoAnalysisOutput — no EMA anchor or leveraged fence.
"""

import json
from typing import Any

from loguru import logger
from pydantic import ValidationError

from analysis.schemas import (
    RegimeAllocationSlot, RegimeAnalysisOutput,
    CryptoAllocationSlot, CryptoAnalysisOutput,
    LEVERAGED_RISK_TICKERS,
    BEAR_HEDGE_TICKERS, BEAR_HEDGE_3X_TICKERS,
)
from config.settings import settings
from portfolio.kelly import compute_kelly_for_slots, normalise_kelly_fractions

# ── Allocation Constants ─────────────────────────────────────────────────────

TARGET_UTILIZATION:    float = 0.82   # 82% of equity actively deployed
MAX_POSITION_KELLY:    float = 0.10   # 10% max per individual position (institutional refactor: was 15%)
MAX_ASSET_CLASS_KELLY: float = 0.35   # 35% max per asset class
MAX_LEVERAGED_KELLY:   float = 0.20   # 20% max for entire leveraged_risk group

SGOV_SLOT_TEMPLATE = {
    "ticker":           "SGOV",
    "asset_class":      "cash",
    "conviction_score": 1.0,
    "kelly_fraction":   0.0,
    "thesis": "Conviction below threshold — holding short-term US Treasury ETF as cash equivalent.",
    "stop_loss_pct":    -0.01,
    "take_profit_pct":   0.01,
}


# ── Slot utilities ────────────────────────────────────────────────────────────

def _renumber_slots(allocations: list[dict]) -> list[dict]:
    for i, slot in enumerate(allocations, start=1):
        slot["slot"] = i
    return allocations


def _inject_sgov_slot(allocations: list[dict], kelly: float, thesis: str) -> list[dict]:
    """Append a SGOV slot with non-zero kelly (will be actively purchased by executor)."""
    if kelly < 0.001:
        return allocations
    max_slot = max(s["slot"] for s in allocations)
    allocations.append({
        **SGOV_SLOT_TEMPLATE,
        "slot":           max_slot + 1,
        "kelly_fraction": round(kelly, 4),
        "thesis":         thesis,
    })
    return _renumber_slots(allocations)


# ── Step 1: SPY 20-Day EMA Regime Anchor ─────────────────────────────────────

def _apply_spy_ema_anchor(data: dict, regime: str) -> tuple[str, dict]:
    """
    Hard gate: Bull regime is ONLY confirmed if SPY price > SPY 20-Day EMA.
    If blocked, regime overrides to Sideways and all leveraged_risk slots
    are replaced with SGOV before any sizing is applied.
    """
    if regime != "Bull":
        return regime, data

    try:
        from data.yfinance_client import get_spy_ema_anchor
        anchor = get_spy_ema_anchor()
    except Exception as exc:
        logger.warning(f"EMA Anchor | Could not read SPY cache: {exc} — permissive (Bull allowed)")
        return regime, data

    spy_price        = anchor.get("spy_price")
    spy_ema_20d      = anchor.get("spy_ema_20d")
    spy_above_ema_20 = anchor.get("spy_above_ema_20")

    if spy_above_ema_20 is None:
        logger.warning("EMA Anchor | SPY EMA-20 data unavailable — permitting Bull regime without anchor check.")
        return regime, data

    if spy_above_ema_20:
        logger.info(
            f"EMA Anchor | SPY ${spy_price:.2f} > EMA-20 ${spy_ema_20d:.2f} — "
            f"Bull regime CONFIRMED. Leveraged risk positions permitted."
        )
        return regime, data

    logger.warning(
        f"EMA Anchor | SPY ${spy_price:.2f} < EMA-20 ${spy_ema_20d:.2f} — "
        f"Bull regime BLOCKED → overriding to Sideways. All LETF slots replaced with SGOV."
    )

    allocations: list[dict] = data.get("allocations", [])
    new_allocs = []
    letf_replaced = 0
    for slot in allocations:
        if slot.get("asset_class") == "leveraged_risk" or slot.get("ticker") in LEVERAGED_RISK_TICKERS:
            new_allocs.append({
                **SGOV_SLOT_TEMPLATE,
                "slot": slot["slot"],
                "thesis": (
                    f"EMA Anchor override: SPY ${spy_price:.2f} < EMA-20 ${spy_ema_20d:.2f}. "
                    f"Leveraged position {slot.get('ticker', '?')} blocked — holding SGOV."
                ),
            })
            letf_replaced += 1
        else:
            new_allocs.append(slot)

    if letf_replaced:
        logger.warning(f"EMA Anchor | {letf_replaced} LETF slot(s) replaced with SGOV.")

    data = {**data, "regime": "Sideways", "allocations": new_allocs}
    return "Sideways", data


# ── Step 2: Conviction Threshold ──────────────────────────────────────────────

def _enforce_conviction_threshold(allocations: list[dict]) -> list[dict]:
    threshold = settings.conviction_threshold
    enforced = []
    for slot in allocations:
        if slot["conviction_score"] < threshold and slot["ticker"] != "SGOV":
            logger.warning(
                f"Allocator | Slot {slot['slot']}: {slot['ticker']} conviction "
                f"{slot['conviction_score']:.0%} < {threshold:.0%} threshold → replacing with SGOV"
            )
            enforced.append({**SGOV_SLOT_TEMPLATE, "slot": slot["slot"]})
        else:
            enforced.append(slot)
    return enforced


# ── Step 3: Volatility-Adjusted Sizing ───────────────────────────────────────

def _apply_volatility_adjusted_weight(allocations: list[dict]) -> list[dict]:
    """
    Assign kelly_fractions using inverse-volatility weighting, targeting
    TARGET_UTILIZATION (82%) of equity deployed.

    Algorithm:
      1. Look up each ticker's 20d annualised volatility from the market-data cache.
      2. weight_i = (1 / vol_i) — lower volatility → larger allocation.
      3. Normalise so the sum = min(TARGET_UTILIZATION, n × MAX_POSITION_KELLY).
      4. Iteratively cap each position at MAX_POSITION_KELLY and redistribute
         the excess to uncapped positions until stable.
      5. Falls back to even-weight if volatility data is unavailable for any ticker.
    """
    threshold = settings.conviction_threshold
    active = [
        s for s in allocations
        if s["ticker"] != "SGOV" and s["conviction_score"] >= threshold
    ]
    if not active:
        return allocations

    n = len(active)

    # ── Collect volatility data ───────────────────────────────────────────────
    try:
        from data.yfinance_client import get_cached_market_data
        cache = get_cached_market_data()
    except Exception:
        cache = None

    inv_vols: dict[str, float] = {}
    missing_vol = []
    for slot in active:
        ticker = slot["ticker"]
        vol = None
        if cache:
            vol = cache.get("by_ticker", {}).get(ticker, {}).get("volatility_20d_annualised_pct")
        if vol and vol > 0:
            inv_vols[ticker] = 1.0 / vol
        else:
            missing_vol.append(ticker)
            inv_vols[ticker] = 1.0  # neutral weight if missing

    if missing_vol:
        logger.info(
            f"Allocator | Vol data missing for {missing_vol} — using uniform inverse-vol weight"
        )

    # ── Compute initial weights ───────────────────────────────────────────────
    total_inv_vol = sum(inv_vols.values())
    # Realistic maximum: can't exceed n × per-asset cap
    realistic_target = min(TARGET_UTILIZATION, n * MAX_POSITION_KELLY)
    conviction_by_ticker: dict[str, float] = {
        slot["ticker"]: min(max(float(slot.get("conviction_score", 1.0)), 0.0), 1.0)
        for slot in active
    }
    raw_weights: dict[str, float] = {
        t: (v / total_inv_vol) * realistic_target * conviction_by_ticker.get(t, 1.0)
        for t, v in inv_vols.items()
    }

    # ── Iterative cap-and-redistribute ───────────────────────────────────────
    weights = dict(raw_weights)
    for _iteration in range(10):
        capped = {t: min(w, MAX_POSITION_KELLY) for t, w in weights.items()}
        excess = sum(weights[t] - capped[t] for t in weights)
        weights = capped

        if excess < 1e-6:
            break
        uncapped = [t for t, w in weights.items() if w < MAX_POSITION_KELLY - 1e-6]
        if not uncapped:
            break
        extra_each = excess / len(uncapped)
        for t in uncapped:
            weights[t] = min(weights[t] + extra_each, MAX_POSITION_KELLY)

    total_deployed = sum(weights.values())
    vol_labels = [f"{t}={w:.1%}" for t, w in sorted(weights.items(), key=lambda x: -x[1])]
    logger.info(
        f"Allocator | Vol-adjusted sizing: [{', '.join(vol_labels)}] "
        f"total={total_deployed:.1%} (target={realistic_target:.1%})"
    )

    # ── Apply weights to allocations ──────────────────────────────────────────
    result = []
    for slot in allocations:
        if slot["ticker"] != "SGOV" and slot["conviction_score"] >= threshold:
            w = round(weights.get(slot["ticker"], 0.0), 4)
            result.append({**slot, "kelly_fraction": w})
        else:
            result.append({**slot, "kelly_fraction": 0.0})
    return result


# ── Step 4: Asset Class Concentration Cap ─────────────────────────────────────

def _enforce_asset_class_cap(allocations: list[dict]) -> list[dict]:
    """
    Cap total kelly_fraction per asset_class to MAX_ASSET_CLASS_KELLY (35%).
    If any class exceeds this, all slots in that class are scaled down
    proportionally and a SGOV slot is injected with the excess kelly.
    """
    class_totals: dict[str, float] = {}
    for slot in allocations:
        if slot["ticker"] == "SGOV" or slot["kelly_fraction"] == 0:
            continue
        cls = slot.get("asset_class", "unknown")
        if cls == "momentum_equity":
            continue
        class_totals[cls] = class_totals.get(cls, 0.0) + slot["kelly_fraction"]

    breached = {cls: total for cls, total in class_totals.items() if total > MAX_ASSET_CLASS_KELLY}
    if not breached:
        return allocations

    for cls, total in breached.items():
        logger.warning(
            f"Allocator | Asset-class cap: {cls} total={total:.1%} > "
            f"{MAX_ASSET_CLASS_KELLY:.0%} cap — scaling down proportionally"
        )

    total_excess = 0.0
    result = []
    for slot in allocations:
        cls = slot.get("asset_class", "unknown")
        if slot["ticker"] != "SGOV" and slot["kelly_fraction"] > 0 and cls in breached:
            scale = MAX_ASSET_CLASS_KELLY / breached[cls]
            original = slot["kelly_fraction"]
            capped = round(original * scale, 4)
            excess = original - capped
            total_excess += excess
            logger.info(
                f"Allocator | Asset-class cap: {slot['ticker']} kelly "
                f"{original:.4f} → {capped:.4f} (excess={excess:.4f})"
            )
            result.append({**slot, "kelly_fraction": capped})
        else:
            result.append(slot)

    if total_excess >= 0.001:
        result = _inject_sgov_slot(
            result, total_excess,
            thesis=f"Asset-class concentration cap: {total_excess:.1%} excess swept from "
                   f"{list(breached.keys())} to SGOV.",
        )

    return result


# ── Step 5: Leveraged Satellite Fence ─────────────────────────────────────────

def _enforce_leveraged_fence(allocations: list[dict]) -> list[dict]:
    """
    Cap total kelly_fraction for the leveraged_risk group to MAX_LEVERAGED_KELLY (20%).
    Also applies the same 20% cap to the 3× bear hedge group (SPXS, SQQQ, SRTY).
    Excess from either group is injected as a non-zero-kelly SGOV slot.
    """
    # ── 1. Standard leveraged_risk fence (TQQQ, SOXL, UPRO) ─────────────────
    leveraged = [
        s for s in allocations
        if (s.get("asset_class") == "leveraged_risk" or s.get("ticker") in LEVERAGED_RISK_TICKERS)
        and s["kelly_fraction"] > 0
    ]
    if leveraged:
        total_leveraged = sum(s["kelly_fraction"] for s in leveraged)
        if total_leveraged > MAX_LEVERAGED_KELLY:
            scale = MAX_LEVERAGED_KELLY / total_leveraged
            excess_kelly = round(total_leveraged - MAX_LEVERAGED_KELLY, 4)
            tickers_capped = [s["ticker"] for s in leveraged]
            logger.warning(
                f"Allocator | Leveraged fence TRIGGERED: {tickers_capped} total={total_leveraged:.1%} "
                f"→ capped to {MAX_LEVERAGED_KELLY:.0%} | excess={excess_kelly:.4f} swept to SGOV"
            )
            result_pass1 = []
            for slot in allocations:
                is_letf = (
                    slot.get("asset_class") == "leveraged_risk"
                    or slot.get("ticker") in LEVERAGED_RISK_TICKERS
                )
                if is_letf and slot["kelly_fraction"] > 0:
                    result_pass1.append({**slot, "kelly_fraction": round(slot["kelly_fraction"] * scale, 4)})
                else:
                    result_pass1.append(slot)
            if excess_kelly >= 0.001:
                result_pass1 = _inject_sgov_slot(
                    result_pass1, excess_kelly,
                    thesis=f"Leveraged risk fence: {excess_kelly:.1%} excess swept from "
                           f"{', '.join(tickers_capped)}.",
                )
            allocations = result_pass1
        else:
            logger.info(
                f"Allocator | Leveraged fence: total={total_leveraged:.1%} ≤ "
                f"{MAX_LEVERAGED_KELLY:.0%} cap — no adjustment"
            )

    # ── 2. Bear hedge 3× fence (SPXS, SQQQ, SRTY) — same 20% combined cap ──
    bear3x = [
        s for s in allocations
        if s.get("ticker") in BEAR_HEDGE_3X_TICKERS
        and s["kelly_fraction"] > 0
    ]
    if bear3x:
        total_bear3x = sum(s["kelly_fraction"] for s in bear3x)
        if total_bear3x > MAX_LEVERAGED_KELLY:
            scale = MAX_LEVERAGED_KELLY / total_bear3x
            excess_kelly = round(total_bear3x - MAX_LEVERAGED_KELLY, 4)
            tickers_capped = [s["ticker"] for s in bear3x]
            logger.warning(
                f"Allocator | Bear-hedge 3× fence TRIGGERED: {tickers_capped} total={total_bear3x:.1%} "
                f"→ capped to {MAX_LEVERAGED_KELLY:.0%} | excess={excess_kelly:.4f} swept to SGOV"
            )
            result_pass2 = []
            for slot in allocations:
                if slot.get("ticker") in BEAR_HEDGE_3X_TICKERS and slot["kelly_fraction"] > 0:
                    result_pass2.append({**slot, "kelly_fraction": round(slot["kelly_fraction"] * scale, 4)})
                else:
                    result_pass2.append(slot)
            if excess_kelly >= 0.001:
                result_pass2 = _inject_sgov_slot(
                    result_pass2, excess_kelly,
                    thesis=f"Bear-hedge 3× fence: {excess_kelly:.1%} excess swept from "
                           f"{', '.join(tickers_capped)}.",
                )
            allocations = result_pass2
        else:
            logger.info(
                f"Allocator | Bear-hedge 3× fence: total={total_bear3x:.1%} ≤ "
                f"{MAX_LEVERAGED_KELLY:.0%} cap — no adjustment"
            )

    return allocations


# ── Sideways Regime Controls ─────────────────────────────────────────────────

SIDEWAYS_MAX_DEPLOYED     = 0.70   # 70% max deployed in Sideways (vs 82% in Bull)
SIDEWAYS_MAX_POSITION_PCT = 0.08   # 8% per position cap (vs 10% in Bull)
SIDEWAYS_SGOV_FLOOR       = 0.30   # 30% minimum SGOV floor in Sideways
SIDEWAYS_MAX_POSITIONS    = 6      # max active (non-SGOV) positions


def _apply_sideways_controls(allocations: list[dict]) -> list[dict]:
    """
    Sideways regime capital deployment.
    Rules:
      - Max 6 active (non-SGOV) positions
      - Per-position kelly cap: 8%
      - Total non-SGOV deployment ≤ 70%
      - Inject SGOV floor so that SGOV represents the remaining ≥ 30%
    """
    non_sgov = [s for s in allocations if s["ticker"] != "SGOV" and s["kelly_fraction"] > 0]
    sgov     = [s for s in allocations if s["ticker"] == "SGOV"]

    # 1. Cap to max 6 positions (drop weakest conviction beyond limit)
    if len(non_sgov) > SIDEWAYS_MAX_POSITIONS:
        non_sgov.sort(key=lambda s: s.get("conviction_score", 0), reverse=True)
        dropped = non_sgov[SIDEWAYS_MAX_POSITIONS:]
        non_sgov = non_sgov[:SIDEWAYS_MAX_POSITIONS]
        for d in dropped:
            logger.info(
                f"Allocator | Sideways: dropped {d['ticker']} (position #{SIDEWAYS_MAX_POSITIONS + 1}+ — max 6)"
            )

    # 2. Per-position 8% cap
    for slot in non_sgov:
        if slot["kelly_fraction"] > SIDEWAYS_MAX_POSITION_PCT:
            logger.info(
                f"Allocator | Sideways: {slot['ticker']} capped "
                f"{slot['kelly_fraction']:.1%} → {SIDEWAYS_MAX_POSITION_PCT:.0%}"
            )
            slot["kelly_fraction"] = SIDEWAYS_MAX_POSITION_PCT

    # 3. Total deployment cap at 70%
    total_deployed = sum(s["kelly_fraction"] for s in non_sgov)
    if total_deployed > SIDEWAYS_MAX_DEPLOYED:
        scale = SIDEWAYS_MAX_DEPLOYED / total_deployed
        for slot in non_sgov:
            slot["kelly_fraction"] = round(slot["kelly_fraction"] * scale, 4)
        logger.info(
            f"Allocator | Sideways: total deployment scaled {total_deployed:.1%} → {SIDEWAYS_MAX_DEPLOYED:.0%}"
        )
        total_deployed = SIDEWAYS_MAX_DEPLOYED

    # 4. Inject SGOV floor for remaining 30%+
    sgov_target = max(SIDEWAYS_SGOV_FLOOR, round(1.0 - total_deployed, 4))
    result = non_sgov + sgov
    result = _inject_sgov_slot(
        result,
        sgov_target,
        thesis=(
            f"Sideways regime: {SIDEWAYS_SGOV_FLOOR:.0%} SGOV floor — "
            f"{total_deployed:.0%} deployed across {len(non_sgov)} position(s)."
        ),
    )

    logger.info(
        f"Allocator | Sideways controls applied | "
        f"kept {len(non_sgov)}/{SIDEWAYS_MAX_POSITIONS} slots | "
        f"deployed cap {total_deployed:.0%} | SGOV kelly {sgov_target:.3f}"
    )
    return _renumber_slots(result)


# ── Bear Regime Controls ──────────────────────────────────────────────────────

BEAR_KELLY_MULTIPLIER = 0.50   # Additional position-size haircut in Bear/RISK-OFF
SAFE_HAVEN_TICKERS    = {"GLD", "TLT", "XLU", "XLP", "XLV"}   # Safe-haven assets checked for positive momentum in Bear regime


def _apply_bear_half_kelly(allocations: list[dict]) -> list[dict]:
    """
    Bear regime capital-preservation step.

    Intended behavior: positions are sized at BEAR_KELLY_MULTIPLIER (0.50) ×
    the even-weight BASE allocation (TARGET_UTILIZATION / n_active), NOT at
    0.50 × the vol-adjusted weight from step 3.

    Why REPLACE rather than multiply:
      - Step 3 (_apply_volatility_adjusted_weight) already adjusts sizing based
        on each asset's volatility. High-vol assets get smaller weights there.
      - If we then also multiply by 0.50 on top of the vol-adjusted weight, a
        high-vol asset is penalised twice: once by inverse-vol sizing, once by
        the Bear multiplier. A low-vol asset only gets the Bear haircut.
      - The correct approach: in Bear regime, use a flat equal-weight base
        (TARGET_UTILIZATION / n) and halve it. This is a capital-preservation
        stance — every position gets the same conservative allowance.

    Safety invariants enforced:
      1. bear_target is capped at MAX_POSITION_KELLY (10%) to prevent large
         allocations when n is small (e.g. n=1 → base_per_slot=82% → cap=10%).
      2. Each slot's new weight = min(bear_target, original_frac). This means:
           - When original_frac > bear_target: slot is REDUCED to bear_target.
             This is the typical capital-preservation case.
           - When original_frac ≤ bear_target: slot stays at original_frac.
             The Bear step does NOT raise a low-vol asset back up to bear_target,
             because raising any slot would violate the "never increase" invariant
             and could increase total risk. Assets already below bear_target are
             already conservatively sized; leaving them unchanged is correct.
      3. Excess = total_original − total_bear_assigned ≥ 0 (always).
    """
    active = [s for s in allocations if s["ticker"] != "SGOV" and s["kelly_fraction"] > 0]
    if not active:
        return allocations

    n = len(active)
    # Base equal-weight per position (pre-vol-adjustment), hard-capped at
    # MAX_POSITION_KELLY so low-n portfolios (1-2 slots) cannot over-allocate.
    base_per_slot = TARGET_UTILIZATION / n
    # Bear target: flat half of the base, still capped at per-asset max.
    bear_target = min(base_per_slot * BEAR_KELLY_MULTIPLIER, MAX_POSITION_KELLY)

    total_original = sum(s["kelly_fraction"] for s in active)
    result = []
    total_bear_assigned = 0.0
    for slot in allocations:
        if slot["ticker"] != "SGOV" and slot["kelly_fraction"] > 0:
            # Invariant: never increase any slot vs its pre-Bear weight.
            # If a high-vol asset's vol-adjusted weight is already below bear_target,
            # we keep it as-is (not raising it back to bear_target).
            new_frac = round(min(bear_target, slot["kelly_fraction"]), 4)
            total_bear_assigned += new_frac
            result.append({**slot, "kelly_fraction": new_frac})
        else:
            result.append(slot)

    # Excess is always >= 0 because new_frac <= original_frac for every slot.
    excess = round(max(total_original - total_bear_assigned, 0.0), 4)

    logger.warning(
        f"Allocator | BEAR Half-Kelly: {n} positions sized at flat "
        f"{bear_target:.1%} each (base={base_per_slot:.1%} × {BEAR_KELLY_MULTIPLIER:.0%}, "
        f"capped at {MAX_POSITION_KELLY:.0%}) — {excess:.1%} excess swept to SGOV"
    )

    if excess >= 0.001:
        result = _inject_sgov_slot(
            result, excess,
            thesis=(
                f"Bear Regime capital preservation: additional {BEAR_KELLY_MULTIPLIER:.0%} position-size "
                f"haircut applied — excess {excess:.1%} held as SGOV."
            ),
        )

    return result


def _has_safe_haven_momentum(allocations: list[dict]) -> bool:
    """
    Returns True if any SGOV-replacement safe-haven asset (GLD or TLT) that
    appears in the allocation list has positive 3-month momentum in the
    market data cache.  If neither ticker is in the allocation, returns True
    (no SGOV sweep — we can't assert the condition is failed).
    """
    present_safe_havens = [
        s["ticker"] for s in allocations
        if s["ticker"] in SAFE_HAVEN_TICKERS and s["ticker"] != "SGOV"
    ]
    if not present_safe_havens:
        return True  # no safe havens in allocation — don't force SGOV

    try:
        from data.yfinance_client import get_cached_market_data
        cache = get_cached_market_data()
        by_ticker = cache.get("by_ticker", {}) if cache else {}
        for ticker in present_safe_havens:
            mom = by_ticker.get(ticker, {}).get("momentum_3mo", "negative")
            if mom == "positive":
                return True
    except Exception as exc:
        # B-11 fix: fail-DEFENSIVE — in a bear/CRISIS path, unknown = defensive.
        # Force SGOV rather than allowing risky allocation when the check can't run.
        # This function is ONLY consulted inside _apply_bear_sgov_default which is
        # ONLY called inside `if regime in _BEAR_REGIMES_ALLOC` — safe to flip;
        # BULL regime never reaches this code.
        logger.warning(
            f"Allocator | _has_safe_haven_momentum check failed — "
            f"defaulting to FORCE SGOV (fail-defensive, bear/CRISIS path only): {exc}"
        )
        return False   # False = no positive safe-haven momentum → SGOV sweep fires

    return False   # no safe haven has positive 3-month momentum


def _apply_bear_sgov_default(allocations: list[dict]) -> list[dict]:
    """
    Bear regime SGOV default sweep.
    If NO safe-haven asset (GLD, TLT) in the allocation shows positive
    3-month momentum, force ALL non-SGOV slots to SGOV.
    This ensures that when even the safe havens are in downtrends the bot
    holds 100% of non-vault equity in short-term Treasuries.
    """
    if _has_safe_haven_momentum(allocations):
        return allocations  # at least one safe haven is bullish — normal allocation OK

    # Calculate total kelly across all non-SGOV slots to preserve for SGOV
    total_redirected = sum(
        s["kelly_fraction"] for s in allocations
        if s["ticker"] != "SGOV" and s["kelly_fraction"] > 0
    )

    logger.warning(
        f"Allocator | BEAR SGOV Default: no safe-haven (GLD/TLT) has positive 3-month momentum — "
        f"ALL {total_redirected:.1%} non-SGOV allocation redirected to SGOV"
    )

    result = []
    max_slot = max(s["slot"] for s in allocations)
    sgov_slot = 1
    for slot in allocations:
        if slot["ticker"] == "SGOV":
            result.append(slot)
        else:
            result.append({
                **SGOV_SLOT_TEMPLATE,
                "slot": slot["slot"],
                "thesis": (
                    f"Bear Regime SGOV Default: no safe-haven has positive 3-month momentum. "
                    f"{slot['ticker']} ({slot.get('asset_class', 'unknown')}) replaced with SGOV."
                ),
            })

    if total_redirected >= 0.001:
        result = _inject_sgov_slot(
            result, total_redirected,
            thesis=(
                f"Bear Regime SGOV Default: {total_redirected:.1%} of equity swept to SGOV "
                f"— no GLD/TLT with positive 3-month momentum."
            ),
        )

    return result


# ── Public Pipeline Functions ─────────────────────────────────────────────────

def process_regime_llm_output(raw_json: str) -> RegimeAnalysisOutput:
    """
    Full regime-switching allocation pipeline.
    Pipeline order:
      parse → EMA anchor → conviction threshold → vol-adjusted sizing
      → asset-class cap → leveraged fence → kelly normalise → Pydantic validate
    """
    try:
        data: dict[str, Any] = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        raise ValueError(f"LLM output is not valid JSON: {exc}") from exc

    allocations: list[dict] = data.get("allocations", [])
    regime = data.get("regime", "unknown")

    if not allocations:
        raise ValueError("LLM returned no allocation slots")

    logger.info(
        f"Allocator | Regime={regime} | {len(allocations)} slot(s) | "
        f"target utilization={TARGET_UTILIZATION:.0%} | "
        f"per-asset cap={MAX_POSITION_KELLY:.0%} | "
        f"class cap={MAX_ASSET_CLASS_KELLY:.0%}"
    )

    # Step 1: SPY EMA Anchor
    regime, data = _apply_spy_ema_anchor(data, regime)
    allocations = data.get("allocations", allocations)

    # Step 2: Conviction threshold
    allocations = _enforce_conviction_threshold(allocations)

    # Step 3: Volatility-adjusted sizing (82% target)
    allocations = _apply_volatility_adjusted_weight(allocations)

    # Step 4: Asset class concentration cap (35%)
    allocations = _enforce_asset_class_cap(allocations)

    # Step 5: Leveraged satellite fence (20%)
    allocations = _enforce_leveraged_fence(allocations)

    # Step 6: Normalise so non-SGOV total ≤ 1.0
    allocations = normalise_kelly_fractions(allocations)

    # ── Sideways Regime Controls ──────────────────────────────────────────────
    # 70% deployed, 8% per position, 30% SGOV floor, max 6 positions.
    _SIDEWAYS_REGIMES_ALLOC = {"Sideways", "sideways", "SIDEWAYS"}
    if regime in _SIDEWAYS_REGIMES_ALLOC:
        logger.info(
            f"Allocator | Sideways Regime ('{regime}') — applying Sideways controls "
            f"(70% deployed, 8% cap, 30% SGOV floor, max 6 positions)"
        )
        allocations = _apply_sideways_controls(allocations)
        allocations = normalise_kelly_fractions(allocations)

    # ── Bear Regime Controls (steps 6a & 6b) ─────────────────────────────────
    # Only applied when the Alpaca bot has confirmed a Bear or RISK-OFF regime.
    _BEAR_REGIMES_ALLOC = {"Bear", "RISK-OFF", "Risk-Off", "bear", "risk-off"}
    if regime in _BEAR_REGIMES_ALLOC:
        logger.warning(
            f"Allocator | Bear Regime active ('{regime}') — applying defensive controls"
        )

        # Step 6a: Bear half-Kelly replacement — replace vol-adjusted weights with
        # flat equal-weight × BEAR_KELLY_MULTIPLIER (0.5), capped at MAX_POSITION_KELLY.
        # This REPLACES (not stacks on top of) vol-adjusted sizing to prevent
        # double-penalising high-vol assets. Excess weight is swept to SGOV.
        allocations = _apply_bear_half_kelly(allocations)

        # Step 6b: SGOV default sweep — if no safe-haven (GLD/TLT) has positive
        # 3-month momentum, redirect ALL remaining capital to SGOV.
        allocations = _apply_bear_sgov_default(allocations)

        # Re-normalise after bear controls (excess was already redistributed to SGOV)
        allocations = normalise_kelly_fractions(allocations)

    # Step 7: Apply hardcoded per-asset-class SL/TP (overrides LLM placeholder values)
    from analysis.hardcoded_exits import apply_hardcoded_exits
    allocations = apply_hardcoded_exits(allocations)

    data["allocations"] = allocations
    data["regime"] = regime

    try:
        output = RegimeAnalysisOutput.model_validate(data)
    except ValidationError as exc:
        logger.error(f"Allocator | Pydantic validation failed:\n{exc}")
        raise

    non_cash = [a for a in output.allocations if a.ticker != "SGOV"]
    leveraged = [a for a in non_cash if a.ticker in LEVERAGED_RISK_TICKERS]
    total_kelly = sum(a.kelly_fraction for a in non_cash)
    total_lev_kelly = sum(a.kelly_fraction for a in leveraged)

    logger.info(
        f"Allocator | Regime={output.regime} | "
        f"{len(non_cash)} active position(s) | "
        f"total deployed={total_kelly:.1%} (target={TARGET_UTILIZATION:.0%}) | "
        f"leveraged_risk={total_lev_kelly:.1%} | "
        f"cash slots={sum(1 for a in output.allocations if a.ticker == 'SGOV')}"
    )

    return output


def process_crypto_llm_output(raw_json: str) -> CryptoAnalysisOutput:
    """
    Crypto-only allocation pipeline for off-hours trading.
    No EMA anchor, asset-class cap, or leveraged fence in crypto mode.
    """
    try:
        data: dict[str, Any] = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        raise ValueError(f"LLM output is not valid JSON: {exc}") from exc

    allocations: list[dict] = data.get("allocations", [])
    if not allocations:
        raise ValueError("LLM returned no crypto allocation slots")

    logger.info(f"Allocator | Crypto mode | {len(allocations)} slot(s)")

    allocations = _enforce_conviction_threshold(allocations)
    allocations = _apply_volatility_adjusted_weight(allocations)
    allocations = normalise_kelly_fractions(allocations)

    # Apply hardcoded per-asset-class SL/TP (overrides LLM placeholder values)
    from analysis.hardcoded_exits import apply_hardcoded_exits
    allocations = apply_hardcoded_exits(allocations)

    data["allocations"] = allocations

    try:
        output = CryptoAnalysisOutput.model_validate(data)
    except ValidationError as exc:
        logger.error(f"Allocator | Crypto Pydantic validation failed:\n{exc}")
        raise

    non_cash = [a for a in output.allocations if a.ticker != "SGOV"]
    total_kelly = sum(a.kelly_fraction for a in non_cash)
    logger.info(
        f"Allocator | Crypto: {len(non_cash)} active position(s) | "
        f"total deployed={total_kelly:.1%}"
    )

    return output

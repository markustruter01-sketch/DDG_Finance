2026-08-29 00:55:38.639 | INFO     | db.postgres:_init_pool:72 - DB | PostgreSQL connection pool initialised (min=2, max=20)
asset_expansion | ordinary_equity_assets=15315 | historical_panel_symbols=streamed | candidate_union=15315
history_coverage | total=15315 | >=252=3918 | partial=502 | none=10895
universe_rule | rank=trailing_60_session_median_dollar_volume | top_n=500
monthly | as_of | count
monthly | 2018-01-02 | 0
monthly | 2018-02-01 | 0
monthly | 2018-03-01 | 0
monthly | 2018-04-02 | 0
monthly | 2018-05-01 | 0
monthly | 2018-06-01 | 0
monthly | 2018-07-02 | 0
monthly | 2018-08-01 | 0
monthly | 2018-09-04 | 0
monthly | 2018-10-01 | 0
monthly | 2018-11-01 | 0
monthly | 2018-12-03 | 0
monthly | 2019-01-02 | 0
monthly | 2019-02-01 | 500
monthly | 2019-03-01 | 500
monthly | 2019-04-01 | 500
monthly | 2019-05-01 | 500
monthly | 2019-06-03 | 500
monthly | 2019-07-01 | 500
monthly | 2019-08-01 | 500
monthly | 2019-09-03 | 500
monthly | 2019-10-01 | 500
monthly | 2019-11-01 | 500
monthly | 2019-12-02 | 500
monthly | 2020-01-02 | 500
monthly | 2020-02-03 | 500
monthly | 2020-03-02 | 500
monthly | 2020-04-01 | 500
monthly | 2020-05-01 | 500
monthly | 2020-06-01 | 500
monthly | 2020-07-01 | 500
monthly | 2020-08-03 | 500
monthly | 2020-09-01 | 500
monthly | 2020-10-01 | 500
monthly | 2020-11-02 | 500
monthly | 2020-12-01 | 500
monthly | 2021-01-04 | 500
monthly | 2021-02-01 | 500
monthly | 2021-03-01 | 500
monthly | 2021-04-01 | 500
monthly | 2021-05-03 | 500
monthly | 2021-06-01 | 500
monthly | 2021-07-01 | 500
monthly | 2021-08-02 | 500
monthly | 2021-09-01 | 500
monthly | 2021-10-01 | 500
monthly | 2021-11-01 | 500
monthly | 2021-12-01 | 500
monthly | 2022-01-03 | 500
monthly | 2022-02-01 | 500
monthly | 2022-03-01 | 500
monthly | 2022-04-01 | 500
monthly | 2022-05-02 | 500
monthly | 2022-06-01 | 500
monthly | 2022-07-01 | 500
monthly | 2022-08-01 | 500
monthly | 2022-09-01 | 500
monthly | 2022-10-03 | 500
monthly | 2022-11-01 | 500
monthly | 2022-12-01 | 500
monthly | 2023-01-03 | 500
monthly | 2023-02-01 | 500
monthly | 2023-03-01 | 500
monthly | 2023-04-03 | 500
monthly | 2023-05-01 | 500
monthly | 2023-06-01 | 500
monthly | 2023-07-03 | 500
monthly | 2023-08-01 | 500
monthly | 2023-09-01 | 500
monthly | 2023-10-02 | 500
monthly | 2023-11-01 | 500
monthly | 2023-12-01 | 500
monthly | 2024-01-02 | 500
monthly | 2024-02-01 | 500
monthly | 2024-03-01 | 500
monthly | 2024-04-01 | 500
monthly | 2024-05-01 | 500
monthly | 2024-06-03 | 500
monthly | 2024-07-01 | 500
monthly | 2024-08-01 | 500
monthly | 2024-09-03 | 500
monthly | 2024-10-01 | 500
monthly | 2024-11-01 | 500
monthly | 2024-12-02 | 500
monthly | 2025-01-02 | 500
monthly | 2025-02-03 | 500
monthly | 2025-03-03 | 500
monthly | 2025-04-01 | 500
monthly | 2025-05-01 | 500
monthly | 2025-06-02 | 500
monthly | 2025-07-01 | 500
monthly | 2025-08-01 | 500
monthly | 2025-09-02 | 500
monthly | 2025-10-01 | 500
monthly | 2025-11-03 | 500
monthly | 2025-12-01 | 500
monthly | 2026-01-02 | 500
monthly | 2026-02-02 | 500
monthly | 2026-03-02 | 500
monthly | 2026-04-01 | 500
monthly | 2026-05-01 | 500
monthly | 2026-06-01 | 500
monthly | 2026-07-01 | 500
monthly | 2026-08-03 | 500
monthly_first_full_500 | as_of=2019-02-01 | count=500
today_rank_cutoff | dollar_volume=71130918.935
annual_implied_floor | year | as_of | rank_500_dollar_volume
annual_implied_floor | 2018 | 2018-01-02 | NONE
annual_implied_floor | 2019 | 2019-01-02 | NONE
annual_implied_floor | 2020 | 2020-01-02 | 14940790.535
annual_implied_floor | 2021 | 2021-01-04 | 25796109.905
annual_implied_floor | 2022 | 2022-01-03 | 32913503.12
annual_implied_floor | 2023 | 2023-01-03 | 28029528.744999997
annual_implied_floor | 2024 | 2024-01-02 | 28070353.125
annual_implied_floor | 2025 | 2025-01-02 | 37348164.29000001
annual_implied_floor | 2026 | 2026-01-02 | 56766832.83
sample_2019 | symbol | dollar_volume | price | name
sample_2019 | AMZN | $7,816,221,573.60 | $91.94 | Amazon.com, Inc. Common Stock
sample_2019 | AAPL | $5,561,382,758.48 | $45.58 | Apple Inc. Common Stock
sample_2019 | MSFT | $3,216,208,457.13 | $114.44 | Microsoft Corporation Common Stock
sample_2019 | META | $2,696,374,916.57 | $177.43 | Meta Platforms, Inc. Class A Common Stock
sample_2019 | BABA | $2,541,475,111.78 | $170.44 | Alibaba Group Holding Limited American Depositary Shares, each represents eight Ordinary Shares
sample_2019 | TSLA | $2,421,026,217.00 | $17.62 | Tesla, Inc. Common Stock
sample_2019 | NFLX | $2,298,288,870.65 | $36.10 | Netflix, Inc. Common Stock
sample_2019 | GOOGL | $1,835,920,844.80 | $59.05 | Alphabet Inc. Class A Common Stock
sample_2019 | AMD | $1,758,943,653.90 | $27.38 | Advanced Micro Devices, Inc. Common Stock
sample_2019 | INTC | $1,043,537,614.22 | $46.09 | Intel Corporation Common Stock
sample_2019 | QCOM | $1,014,950,687.48 | $55.79 | QUALCOMM Incorporated Common Stock
sample_2019 | MU | $997,011,704.55 | $39.34 | Micron Technology, Inc. Common Stock
sample_2019 | CSCO | $950,631,675.45 | $44.18 | Cisco Systems, Inc. Common Stock (DE)
sample_2019 | ROKU | $822,163,335.56 | $64.72 | Roku, Inc. Class A Common Stock
sample_2019 | BKNG | $809,688,219.62 | $69.50 | Booking Holdings Inc. Common Stock
sample_2019 | ADBE | $710,543,990.80 | $271.86 | Adobe Inc. Common Stock
sample_2019 | PYPL | $686,097,821.54 | $106.52 | PayPal Holdings, Inc. Common Stock
sample_2019 | APC | $669,124,445.76 | $61.24 | ARKO Petroleum Corp. Class A Common Stock
sample_2019 | CELG | $653,343,668.65 | $94.19 | Celgene Corporation Common Stock
sample_2019 | AVGO | $636,699,028.20 | $25.15 | Broadcom Inc. Common Stock
today_top_20 | symbol | momentum | dollar_volume | price | sector | asset_class
today_top_20 | ARWR | +295.6861% | $120,475,463.28 | $88.59 | unknown | ordinary_equity
today_top_20 | ICHR | +257.9643% | $76,235,382.12 | $59.09 | unknown | ordinary_equity
today_top_20 | VICR | +256.1282% | $202,792,790.68 | $203.64 | unknown | ordinary_equity
today_top_20 | APGE | +255.1204% | $149,077,723.16 | $134.96 | unknown | ordinary_equity
today_top_20 | MXL | +241.9952% | $240,322,573.00 | $63.42 | unknown | ordinary_equity
today_top_20 | HUT | +234.6490% | $430,899,608.09 | $87.13 | unknown | ordinary_equity
today_top_20 | TXG | +230.3852% | $122,304,476.31 | $64.85 | unknown | ordinary_equity
today_top_20 | INTC | +229.4970% | $12,321,023,979.68 | $92.09 | technology | ordinary_equity
today_top_20 | TVTX | +218.5780% | $85,250,063.71 | $67.52 | unknown | ordinary_equity
today_top_20 | TSEM | +218.3729% | $379,937,334.10 | $219.85 | unknown | ordinary_equity
today_top_20 | AAOI | +218.1705% | $1,450,356,940.74 | $113.28 | unknown | ordinary_equity
today_top_20 | TWST | +214.3435% | $151,304,514.85 | $153.10 | unknown | ordinary_equity
today_top_20 | LQDA | +210.0714% | $117,083,764.07 | $69.94 | unknown | ordinary_equity
today_top_20 | IBRX | +191.8803% | $71,558,813.04 | $8.40 | unknown | ordinary_equity
today_top_20 | UCTT | +189.9958% | $127,476,276.70 | $74.75 | unknown | ordinary_equity
today_top_20 | BTSG | +189.8872% | $193,337,765.65 | $60.90 | unknown | ordinary_equity
today_top_20 | VIAV | +189.3178% | $226,288,060.06 | $38.45 | unknown | ordinary_equity
today_top_20 | HMHC | +188.5517% | $78,735,875.41 | $21.03 | unknown | ordinary_equity
today_top_20 | FORM | +185.1042% | $160,616,712.20 | $110.23 | unknown | ordinary_equity
today_top_20 | GSAT | +178.6170% | $82,587,008.09 | $82.05 | unknown | ordinary_equity
today_sanity | count=20 | included_non_ordinary=0 | etf_count=0
delisted_era_members | early_date=2019-06-03 | late_date=2026-06-01 | count=64
verification | execution_mode=read_only | bot2_paused=true | orders_placed=0 | published=0 | stop_coverage=8/8
run_exit_status=2

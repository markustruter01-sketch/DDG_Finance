2026-08-29 02:12:33.520 | INFO     | db.postgres:_init_pool:72 - DB | PostgreSQL connection pool initialised (min=2, max=20)
experiment_preregistered | strategy_family=bot2_momentum_rank500 | experiment_id=18 | status=resume_uncompleted
asset_preflight | stored_assets=15315 | static_eligible=3481 | candidate_symbols=3481
panel_loaded | symbols=3451 | bars=5215375 | from=2018-01-01 | through=2026-07-31 | storage=compact_streamed
screener_confirmation | implementation=core.equity_universe.screen_universe | rank_metric=trailing_60_session_median_dollar_volume | universe_size=500
window_selection | first_full_500=2019-02-01 | latest_complete_month_end=2026-07-31 | windows=[["2019_2020", "2019-02-01", "2020-12-31"], ["2021_2022", "2021-01-01", "2022-12-31"], ["2023_2024", "2023-01-01", "2024-12-31"], ["2025_latest_complete", "2025-01-01", "2026-07-31"], ["pooled_2019-02_latest_complete", "2019-02-01", "2026-07-31"]]
ranking_cache | monthly_rebalances=103
random_control | window=2019_2020 | iterations=1000 | mean=0.633200 | p05=0.337698 | p95=1.007617
random_control | window=2021_2022 | iterations=1000 | mean=-0.271566 | p05=-0.403968 | p95=-0.113122
random_control | window=2023_2024 | iterations=1000 | mean=0.206829 | p05=-0.033968 | p95=0.496018
random_control | window=2025_latest_complete | iterations=1000 | mean=0.255259 | p05=-0.004914 | p95=0.555800
random_control | window=pooled_2019-02_latest_complete | iterations=1000 | mean=0.722592 | p05=0.084079 | p95=1.612447
result | window=2019_2020 | sharpe=1.798413 | sortino=2.781139 | return=1.916103 | maxDD=0.249013 | trades=460 | turnover=70.696763 | cost_drag=0.070798 | mean_deployment=0.881268 | max_deployment=1.000000 | random_actual_percentile=100.00
result | window=2021_2022 | sharpe=-0.348566 | sortino=-0.479560 | return=-0.347327 | maxDD=0.670794 | trades=480 | turnover=43.016744 | cost_drag=0.042723 | mean_deployment=0.767221 | max_deployment=1.000000 | random_actual_percentile=21.30
result | window=2023_2024 | sharpe=0.699018 | sortino=1.036318 | return=0.401942 | maxDD=0.276740 | trades=480 | turnover=55.679050 | cost_drag=0.053360 | mean_deployment=0.880800 | max_deployment=1.000000 | random_actual_percentile=88.40
result | window=2025_latest_complete | sharpe=0.905040 | sortino=1.311871 | return=0.614637 | maxDD=0.318257 | trades=380 | turnover=50.192856 | cost_drag=0.050748 | mean_deployment=0.795317 | max_deployment=1.000000 | random_actual_percentile=96.90
result | window=pooled_2019-02_latest_complete | sharpe=0.701688 | sortino=1.017661 | return=3.218343 | maxDD=0.720157 | trades=1800 | turnover=429.978889 | cost_drag=0.430597 | mean_deployment=0.832674 | max_deployment=1.000000 | random_actual_percentile=100.00
benchmark | window=2019_2020 | strategy=spy_buy_and_hold | sharpe=0.895695 | sortino=1.215574 | return=0.438286 | maxDD=0.337938 | trades=1 | turnover=2.438097 | cost_drag=0.002436 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=2019_2020 | strategy=equal_weight_top500_buy_and_hold | sharpe=1.008864 | sortino=1.364547 | return=0.597173 | maxDD=0.363457 | trades=1 | turnover=2.594830 | cost_drag=0.002597 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=2021_2022 | strategy=spy_buy_and_hold | sharpe=0.265379 | sortino=0.374127 | return=0.067340 | maxDD=0.244961 | trades=1 | turnover=2.084453 | cost_drag=0.002048 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=2021_2022 | strategy=equal_weight_top500_buy_and_hold | sharpe=-0.190315 | sortino=-0.265052 | return=-0.149387 | maxDD=0.348510 | trades=1 | turnover=1.868511 | cost_drag=0.001834 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=2023_2024 | strategy=spy_buy_and_hold | sharpe=1.865702 | sortino=2.795181 | return=0.582418 | maxDD=0.099726 | trades=1 | turnover=2.591155 | cost_drag=0.002566 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=2023_2024 | strategy=equal_weight_top500_buy_and_hold | sharpe=1.074352 | sortino=1.573399 | return=0.447089 | maxDD=0.177327 | trades=1 | turnover=2.465381 | cost_drag=0.002418 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=2025_latest_complete | strategy=spy_buy_and_hold | sharpe=1.038140 | sortino=1.561090 | return=0.299702 | maxDD=0.187557 | trades=1 | turnover=2.307536 | cost_drag=0.002288 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=2025_latest_complete | strategy=equal_weight_top500_buy_and_hold | sharpe=0.933548 | sortino=1.384114 | return=0.343513 | maxDD=0.235783 | trades=1 | turnover=2.345713 | cost_drag=0.002338 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=pooled_2019-02_latest_complete | strategy=spy_buy_and_hold | sharpe=0.887154 | sortino=1.250732 | return=2.092012 | maxDD=0.337938 | trades=1 | turnover=4.090168 | cost_drag=0.004088 | mean_deployment=1.000000 | max_deployment=1.000000
benchmark | window=pooled_2019-02_latest_complete | strategy=equal_weight_top500_buy_and_hold | sharpe=0.629511 | sortino=0.883353 | return=1.465419 | maxDD=0.363457 | trades=1 | turnover=3.462208 | cost_drag=0.003466 | mean_deployment=1.000000 | max_deployment=1.000000
evaluation | outcome=FAIL | checks={'sharpe': True, 'max_drawdown': False, 'beats_spy_risk_adjusted': False, 'beats_random_entry': True, 'max_deployment_cap': True}
criterion | name=sharpe | result=PASS
criterion | name=max_drawdown | result=FAIL
criterion | name=beats_spy_risk_adjusted | result=FAIL
criterion | name=beats_random_entry | result=PASS
criterion | name=max_deployment_cap | result=PASS
lookahead_check | pooled_sharpe=0.701688 | status=NOT_TRIGGERED
sector_reference | source=static_map_plus_sec_sic | requested=365 | unknown=155
snapshot_screen | as_of=2019-06-03 | qualified=500 | ranked_candidates=1427 | rank_cutoff_dollar_volume=9658306.489999998
snapshot_top20 | as_of=2019-06-03 | symbol=AXSM | momentum=4.277612 | dollar_volume=21627567.09 | price=22.9600 | sector=healthcare
snapshot_top20 | as_of=2019-06-03 | symbol=TNDM | momentum=3.250891 | dollar_volume=105369583.76 | price=68.5600 | sector=unknown
snapshot_top20 | as_of=2019-06-03 | symbol=VCYT | momentum=2.290196 | dollar_volume=15570391.535 | price=22.6600 | sector=unknown
snapshot_top20 | as_of=2019-06-03 | symbol=MDB | momentum=1.835137 | dollar_volume=175629318.375 | price=140.3400 | sector=technology
snapshot_top20 | as_of=2019-06-03 | symbol=CRON | momentum=1.733974 | dollar_volume=100385225.32 | price=14.0800 | sector=materials
snapshot_top20 | as_of=2019-06-03 | symbol=EHTH | momentum=1.619897 | dollar_volume=27201624.08 | price=70.5600 | sector=financials
snapshot_top20 | as_of=2019-06-03 | symbol=COKE | momentum=1.589167 | dollar_volume=16839828.2 | price=28.5900 | sector=utilities
snapshot_top20 | as_of=2019-06-03 | symbol=TTD | momentum=1.586227 | dollar_volume=291289876.5 | price=19.8800 | sector=unknown
snapshot_top20 | as_of=2019-06-03 | symbol=UPBD | momentum=1.580500 | dollar_volume=18102460.04 | price=16.7100 | sector=unknown
snapshot_top20 | as_of=2019-06-03 | symbol=ZS | momentum=1.519802 | dollar_volume=146406732.185 | price=68.6300 | sector=technology
snapshot_top20 | as_of=2019-06-03 | symbol=LSCC | momentum=1.346087 | dollar_volume=21409854.33 | price=12.8000 | sector=technology
snapshot_top20 | as_of=2019-06-03 | symbol=IIPR | momentum=1.344475 | dollar_volume=19102788.95 | price=49.5000 | sector=real_estate
snapshot_top20 | as_of=2019-06-03 | symbol=ENPH | momentum=1.265271 | dollar_volume=24685314.485 | price=15.1700 | sector=energy
snapshot_top20 | as_of=2019-06-03 | symbol=UI | momentum=1.069577 | dollar_volume=57396503.75 | price=112.8000 | sector=unknown
snapshot_top20 | as_of=2019-06-03 | symbol=CDNA | momentum=1.043807 | dollar_volume=27034506.825 | price=31.6200 | sector=healthcare
snapshot_top20 | as_of=2019-06-03 | symbol=BAND | momentum=1.017154 | dollar_volume=13569239.02 | price=72.5700 | sector=technology
snapshot_top20 | as_of=2019-06-03 | symbol=FIVE | momentum=1.012445 | dollar_volume=137913935.925 | price=128.7300 | sector=consumer_discretionary
snapshot_top20 | as_of=2019-06-03 | symbol=MRCY | momentum=1.008123 | dollar_volume=25242708.080000002 | price=68.7600 | sector=technology
snapshot_top20 | as_of=2019-06-03 | symbol=FNKO | momentum=0.995976 | dollar_volume=12060029.715 | price=20.7600 | sector=unknown
snapshot_top20 | as_of=2019-06-03 | symbol=RAMP | momentum=0.964493 | dollar_volume=37743605.94 | price=51.3800 | sector=unknown
snapshot_screen | as_of=2022-06-01 | qualified=500 | ranked_candidates=1961 | rank_cutoff_dollar_volume=24664262.369999997
snapshot_top20 | as_of=2022-06-01 | symbol=CAR | momentum=2.089783 | dollar_volume=221578943.0 | price=180.7900 | sector=unknown
snapshot_top20 | as_of=2022-06-01 | symbol=LNTH | momentum=1.713935 | dollar_volume=70123151.975 | price=68.5200 | sector=unknown
snapshot_top20 | as_of=2022-06-01 | symbol=DJT | momentum=1.043826 | dollar_volume=107072510.475 | price=43.7100 | sector=technology
snapshot_top20 | as_of=2022-06-01 | symbol=IRTC | momentum=0.965429 | dollar_volume=43420536.510000005 | price=140.8500 | sector=healthcare
snapshot_top20 | as_of=2022-06-01 | symbol=CYTK | momentum=0.904011 | dollar_volume=37533394.45 | price=39.9000 | sector=healthcare
snapshot_top20 | as_of=2022-06-01 | symbol=CCXI | momentum=0.809804 | dollar_volume=26226491.520000003 | price=22.2700 | sector=industrials
snapshot_top20 | as_of=2022-06-01 | symbol=TSEM | momentum=0.780317 | dollar_volume=37541317.644999996 | price=48.2600 | sector=unknown
snapshot_top20 | as_of=2022-06-01 | symbol=APA | momentum=0.758296 | dollar_volume=351842753.505 | price=40.7700 | sector=energy
snapshot_top20 | as_of=2022-06-01 | symbol=SITM | momentum=0.719576 | dollar_volume=40677421.239999995 | price=213.0000 | sector=unknown
snapshot_top20 | as_of=2022-06-01 | symbol=SBLK | momentum=0.704091 | dollar_volume=44279797.275 | price=20.8500 | sector=unknown
snapshot_top20 | as_of=2022-06-01 | symbol=PTEN | momentum=0.675663 | dollar_volume=58762726.745000005 | price=16.5800 | sector=unknown
snapshot_top20 | as_of=2022-06-01 | symbol=DLTR | momentum=0.657484 | dollar_volume=395816389.70000005 | price=160.3300 | sector=consumer_staples
snapshot_top20 | as_of=2022-06-01 | symbol=MGY | momentum=0.638695 | dollar_volume=42361731.95 | price=25.0600 | sector=energy
snapshot_top20 | as_of=2022-06-01 | symbol=NTR | momentum=0.599851 | dollar_volume=303613229.245 | price=85.1900 | sector=materials
snapshot_top20 | as_of=2022-06-01 | symbol=EXE | momentum=0.591499 | dollar_volume=143439242.385 | price=82.1400 | sector=energy
snapshot_top20 | as_of=2022-06-01 | symbol=PANW | momentum=0.569368 | dollar_volume=1001380009.6800001 | price=83.8000 | sector=technology
snapshot_top20 | as_of=2022-06-01 | symbol=CHRD | momentum=0.551573 | dollar_volume=33152170.865000002 | price=108.1000 | sector=energy
snapshot_top20 | as_of=2022-06-01 | symbol=PBR | momentum=0.520357 | dollar_volume=166180675.365 | price=6.0760 | sector=unknown
snapshot_top20 | as_of=2022-06-01 | symbol=EQNR | momentum=0.506345 | dollar_volume=94627796.96000001 | price=26.4900 | sector=energy
snapshot_top20 | as_of=2022-06-01 | symbol=EXC | momentum=0.488320 | dollar_volume=310883546.48 | price=42.4800 | sector=utilities
snapshot_screen | as_of=2026-06-01 | qualified=500 | ranked_candidates=2022 | rank_cutoff_dollar_volume=54517204.81
snapshot_top20 | as_of=2026-06-01 | symbol=AXTI | momentum=45.756579 | dollar_volume=884917216.53 | price=103.1600 | sector=technology
snapshot_top20 | as_of=2026-06-01 | symbol=SNDK | momentum=26.570207 | dollar_volume=14441944115.73 | price=1694.9800 | sector=unknown
snapshot_top20 | as_of=2026-06-01 | symbol=ABVX | momentum=16.662510 | dollar_volume=105015078.63499999 | price=132.6300 | sector=healthcare
snapshot_top20 | as_of=2026-06-01 | symbol=LWLG | momentum=11.122462 | dollar_volume=84105721.97 | price=10.8600 | sector=unknown
snapshot_top20 | as_of=2026-06-01 | symbol=LITE | momentum=10.382045 | dollar_volume=4879846746.675 | price=854.9600 | sector=unknown
snapshot_top20 | as_of=2026-06-01 | symbol=HYMC | momentum=10.253289 | dollar_volume=86993361.46000001 | price=33.0500 | sector=unknown
snapshot_top20 | as_of=2026-06-01 | symbol=CELC | momentum=9.998152 | dollar_volume=93941959.66499999 | price=132.8800 | sector=healthcare
snapshot_top20 | as_of=2026-06-01 | symbol=AAOI | momentum=8.027171 | dollar_volume=1564989390.92 | price=158.4100 | sector=technology
snapshot_top20 | as_of=2026-06-01 | symbol=ONDS | momentum=7.869159 | dollar_volume=585297405.6500001 | price=13.2200 | sector=communication
snapshot_top20 | as_of=2026-06-01 | symbol=PRAX | momentum=7.405462 | dollar_volume=117945739.14500001 | price=349.9700 | sector=unknown
snapshot_top20 | as_of=2026-06-01 | symbol=AEHR | momentum=7.213855 | dollar_volume=201098982.575 | price=92.3300 | sector=utilities
snapshot_top20 | as_of=2026-06-01 | symbol=CRML | momentum=7.187050 | dollar_volume=86268196.925 | price=11.2000 | sector=materials
snapshot_top20 | as_of=2026-06-01 | symbol=OPEN | momentum=7.134111 | dollar_volume=169603185.52499998 | price=5.0400 | sector=real_estate
snapshot_top20 | as_of=2026-06-01 | symbol=WDC | momentum=6.888549 | dollar_volume=2666912213.3999996 | price=531.0700 | sector=unknown
snapshot_top20 | as_of=2026-06-01 | symbol=NKTR | momentum=6.502254 | dollar_volume=58915597.365 | price=64.8800 | sector=healthcare
snapshot_top20 | as_of=2026-06-01 | symbol=COGT | momentum=5.509982 | dollar_volume=64294554.42 | price=34.9600 | sector=healthcare
snapshot_top20 | as_of=2026-06-01 | symbol=VSAT | momentum=5.394822 | dollar_volume=89931176.03 | price=80.6200 | sector=unknown
snapshot_top20 | as_of=2026-06-01 | symbol=ERAS | momentum=5.282759 | dollar_volume=78141256.86500001 | price=12.8400 | sector=healthcare
snapshot_top20 | as_of=2026-06-01 | symbol=VICR | momentum=5.001870 | dollar_volume=166109908.62 | price=334.8400 | sector=unknown
snapshot_top20 | as_of=2026-06-01 | symbol=ECHO | momentum=4.938523 | dollar_volume=654264412.41 | price=129.1900 | sector=unknown
sector_diversification | average_distinct_sectors_per_month=5.349515
largest_monthly_drawdown | month=2021-02 | date=2021-02-25 | drawdown=0.217771 | held=AGNT,ALTO,APPS,CELH,GRWG,MARA,MVIS,NVAX,RIOT,VERI
results_recorded | strategy_family=bot2_momentum_rank500 | experiment_id=18 | outcome=FAIL | recorded_once=true
verification | execution_mode=development_read_only | bot2_unpaused=0 | orders_placed=0 | published=0 | bot1_touched=0 | bot3_touched=0 | vault_touched=0 | monitoring_touched=0 | published_runner_cycling=not_checked_no_publish | production_stop_coverage=8/8 | max_deployment_cap=PASS
run_exit_status=4

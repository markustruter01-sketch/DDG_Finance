from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, field_validator


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- Data Source Keys ---
    fred_api_key: str = Field(..., description="FRED API key from fred.stlouisfed.org")
    news_api_key: str = Field(..., description="NewsAPI key from newsapi.org")

    # --- Alpaca (Paper Trading) ---
    alpaca_api_key: str = Field(default="", description="Alpaca paper trading API key")
    alpaca_secret_key: str = Field(default="", description="Alpaca paper trading secret key")
    alpaca_base_url: str = Field(
        default="https://paper-api.alpaca.markets",
        description="Alpaca paper trading base URL",
    )

    # --- LLM ---
    groq_api_key: str = Field(..., description="Groq API key (GROQ_API_KEY) — used for Navigator news blackout detection")
    anthropic_api_key: str = Field(default="", description="Claude API key (optional future use)")
    deepseek_api_key: str = Field(default="", description="DeepSeek API key (optional future use)")

    # --- Trading Constraints ---
    conviction_threshold: float = Field(
        default=0.75,
        description="Minimum LLM conviction score (0-1) required to place a trade",
    )
    kill_switch_drawdown_pct: float = Field(
        default=0.15,
        description="Fleet drawdown fraction from high-water mark that triggers the kill switch",
    )
    kill_switch_missing_stop_seconds: float = Field(default=60.0)
    kill_switch_check_interval_minutes: int = Field(default=5)
    kill_switch_portfolio_stale_hours: float = Field(default=2.0)
    kill_switch_armed: bool = Field(
        default=False,
        description="Explicit second gate for enforcement; production alone never arms the switch",
    )
    total_capital_slots: int = Field(
        default=10,
        description="Total number of capital allocation slots",
    )
    cash_equivalent_ticker: str = Field(
        default="SGOV",
        description="Ticker used to fill empty/low-conviction slots",
    )

    # --- Groq Fallback ---
    regime_fallback_max_age_hours: float = Field(
        default=1.5,
        description="How many hours a cached regime analysis remains valid for pipeline fallback when Groq is rate-limited",
    )

    # --- Groq Budget Guardrails ---
    groq_daily_token_budget: int = Field(
        default=10_000_000,
        description="Daily token budget for the LLM (now Gemini via Replit proxy — effectively unlimited). Interval throttle still applies. Resets at midnight UTC.",
    )
    groq_min_regime_interval_minutes: int = Field(
        default=90,
        description="Minimum minutes between regime/crypto LLM calls. Enforces proactive budget pacing. 0 = disabled.",
    )
    groq_commentary_daily_cap: int = Field(
        default=4,
        description="Max auto-triggered commentary refreshes per endpoint per day (Alpaca + Kraken counted separately). Force=true bypasses cap.",
    )

    # --- Throttling ---
    max_retries: int = Field(
        default=5,
        description="Maximum retry attempts for API calls with exponential backoff",
    )
    backoff_min_wait: float = Field(
        default=1.0,
        description="Minimum wait seconds between retries",
    )
    backoff_max_wait: float = Field(
        default=60.0,
        description="Maximum wait seconds between retries",
    )

    # --- Logging ---
    log_level: str = Field(default="INFO", description="Loguru log level")
    log_file: str = Field(default="logs/trading.log", description="Log file path")

    @field_validator(
        "fred_api_key", "news_api_key",
        "alpaca_api_key", "alpaca_secret_key",
        "groq_api_key", "anthropic_api_key", "deepseek_api_key",
        mode="before",
    )
    @classmethod
    def strip_whitespace(cls, v: str) -> str:
        return v.strip() if isinstance(v, str) else v


settings = Settings()
